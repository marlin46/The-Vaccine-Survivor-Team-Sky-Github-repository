﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ScoreSystem : MonoBehaviour
{
    public static ScoreSystem Instance;
    public TextMeshProUGUI scoreText;
    public static int score;
    void Start()
    {
        score = 0;
        Instance = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void UpdateScore(int amount)
    {
        score += amount;
        scoreText.text = score.ToString();
    }
}
