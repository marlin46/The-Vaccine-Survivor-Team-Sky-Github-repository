﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SwitchScreenVC : MonoBehaviour
{
    
    // Start is called before the first frame update
    public void HomeScreen()
    {
        Debug.Log("Entering home");
        SceneManager.LoadScene("Home");
    }
    public void Credits(){
        Debug.Log("Entering Credits");
        SceneManager.LoadScene("Credits");
    }

    // Update is called once per frame
    /*public void LevelScreen()
    {
        SceneManager.LoadScene("Level");
    }*/
    public void LevelOne()
    {
        Debug.Log("Entering Levelone");
        SceneManager.LoadScene("Game");
    }
    public void CaseFiles()
    {
        Debug.Log("Entering CaseFiles debug");
        SceneManager.LoadScene("Case Files");
    }
    public void Opioid()
    {
        Debug.Log("Entering Opioid debug");
        SceneManager.LoadScene("Opioid CF");
    }
    public void Flu()
    {
        Debug.Log("Entering flu debug");
        SceneManager.LoadScene("Flu CF");
    }
    public void HumanInfectedVirus()
    {
        Debug.Log("Entering HIV debug");
        SceneManager.LoadScene("HIV CF");
    }
    public void Cold()
    {
        Debug.Log("Entering Cold debug");
        SceneManager.LoadScene("Cold CF");
    }
    public void Covid()
    {
        Debug.Log("Entering Covid debug");
        SceneManager.LoadScene("COVID CF");
    }
    public void Lose()
    {
        Debug.Log("Entering Lose debug");
        SceneManager.LoadScene("Lose");
    }

    public void TestForThis(){
        Debug.Log("Test");
    }
}
