﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SwitchScreen : MonoBehaviour
{
    // Start is called before the first frame update
    public void HomeScreen()
    {
        SceneManager.LoadScene("Home");
    }

    // Update is called once per frame
    /*public void LevelScreen()
    {
        SceneManager.LoadScene("Level");
    }*/
    public void LevelOne()
    {
        SceneManager.LoadScene("AppDev1");
    }
    public void LevelTwo(){
        SceneManager.LoadScene("AppDev2");
    }
}
