﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerCollisionVC : MonoBehaviour
{
     public PlayerMovement movement;
     public bool ToWin = false;

    void OnCollisionEnter2D(Collision2D collisionInfo)
    {
        Debug.Log("InPlayColl");
        if(collisionInfo.gameObject.tag == "Enemy")
        {
           Debug.Log("Game Over enemy debug PlayerCol");
           movement.enabled = false;
           //FindObjectOfType<AudioManager>().Play("PlayerDeath");
           SceneManager.LoadScene("Lose");
           
        }
        else if(collisionInfo.collider.tag == "Finish")
            {
                Debug.Log("Finish debug in PlayerCol!");
                movement.enabled = false;
                SceneManager.LoadScene("Win");

                //animator.SetBool("IsDead", false);
                //Invoke("Restart", 2f);
            }
    }
     void OnTriggerEnter2D(Collider2D col) {
        Debug.Log("OnTriggerEnter2d");
        if(col.gameObject.tag == "Enemy"){
            Debug.Log("True!");
            movement.enabled = false;
            SceneManager.LoadScene("Lose");
        }
         else if(col.gameObject.tag == "Finish")
         {
                Debug.Log("Finish debug in PlayerCol!");
                movement.enabled = false;
                SceneManager.LoadScene("Win");
                // movement.enabled = false;
                // SceneManager.LoadScene("Win");

                //animator.SetBool("IsDead", false);
                //Invoke("Restart", 2f);
            }
    }
}
