﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerCollision : MonoBehaviour
{
    public PlayerMovement movement;

    void OnCollisionEnter2D(Collision2D collisionInfo)
    {
        Debug.Log("InPlayColl");
        if(collisionInfo.gameObject.tag == "Enemy")
        {
           Debug.Log("Game Over enemy debug PlayerCol");
           movement.enabled = false;
           //FindObjectOfType<AudioManager>().Play("PlayerDeath");
           SceneManager.LoadScene("Lose");
           
        }
        else if(collisionInfo.collider.tag == "Finish")
            {
                Debug.Log("Finish debug in PlayerCol!");
                movement.enabled = false;
                SceneManager.LoadScene("Win");

                //animator.SetBool("IsDead", false);
                //Invoke("Restart", 2f);
            }
    }
    
}
